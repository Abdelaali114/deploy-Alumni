
== Agora App Builder ==
Instructions to run your project:

Note: 
1. Please make sure to remove empty spaces in the project folder path to avoid installation error
2. On Windows if you have encountered the error -> Boilerplate creation was unsuccessful then run this command npm i -g npm@latest

1. Open a terminal inside this folder
2. Run - npm i && npm start (You need NodeJS v18.x or higher version installed on your system)
3. Select install through the CLI menu
4. Build for any supported platform
